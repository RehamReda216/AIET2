package com.example.aiet2;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class ProfSelection_frag extends Fragment {
    Button btn_man;
    Button btn_vAttP;
    Button dAttP;
    Button btn_sgnP;
    MainActivity mainActivity;
    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view_ProfSelection_Frag = inflater.inflate(R.layout.fragment_prof_selection, container, false);
        btn_sgnP = view_ProfSelection_Frag.findViewById(R.id.btn_sgnP);
        btn_sgnP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.addFragment(R.layout.fragment_button_frag);
            }
        });
        return view_ProfSelection_Frag;
    }

}