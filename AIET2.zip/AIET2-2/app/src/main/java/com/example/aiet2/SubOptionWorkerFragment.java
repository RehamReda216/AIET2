package com.example.aiet2;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class SubOptionWorkerFragment extends Fragment {
    Button btnWorkerLogin;
    Button btnCaptureWorkerAtt;
    MainActivity mainActivity;
    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view_wokfrag =inflater.inflate(R.layout.fragment_worker, container, false);
        btnWorkerLogin=view_wokfrag.findViewById(R.id.btnWorkerLogin);
        btnCaptureWorkerAtt=view_wokfrag.findViewById(R.id.btnCaptureWorkerAtt);
        btnWorkerLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.addFragment(R.layout.fragment_login);
            }
        });
        btnCaptureWorkerAtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { mainActivity.addFragment(R.layout.fragment_connection_establish);}
        });

        return view_wokfrag;
    }

}