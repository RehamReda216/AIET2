package com.example.aiet2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragmentManager = getSupportFragmentManager();
        addFragment(R.layout.fragment_main);

    }

    public void addFragment(long id) {
        if (id == R.layout.fragment_main) {
            fragmentTransaction = fragmentManager.beginTransaction();
            MainFragment mainFragment = new MainFragment();
            mainFragment.setActivity(this);
            fragmentTransaction.add(R.id.Main_layout,mainFragment);
            fragmentTransaction.commit();

        } else if (id == R.layout.fragment_student) {
            fragmentTransaction = fragmentManager.beginTransaction();
            SubOptionStudentFragment subOptionStudentFragment  = new SubOptionStudentFragment();
            subOptionStudentFragment.setActivity(this);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.Main_layout,subOptionStudentFragment);
            fragmentTransaction.commit();
        } else if (id == R.layout.fragment_prof_assis) {
            fragmentTransaction = fragmentManager.beginTransaction();
            SubOptionProfAssisFragment subOptionProfAssisFragment = new SubOptionProfAssisFragment();
            subOptionProfAssisFragment.setActivity(this);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.Main_layout, subOptionProfAssisFragment);
            fragmentTransaction.commit();
        } else if (id == R.layout.fragment_worker) {
            fragmentTransaction = fragmentManager.beginTransaction();
            SubOptionWorkerFragment subOptionWorkerFragment = new SubOptionWorkerFragment();
            subOptionWorkerFragment.setActivity(this);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.Main_layout,subOptionWorkerFragment);
            fragmentTransaction.commit();

        } else if (id == R.layout.fragment_login) {
            fragmentTransaction = fragmentManager.beginTransaction();
            LoginFragment loginFragment = new LoginFragment();
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.Main_layout, loginFragment);
            fragmentTransaction.commit();

        }
        else if (id == R.layout.fragment_connection_establish) {
            fragmentTransaction = fragmentManager.beginTransaction();
            ConnectionEstablishFragment connectionEstablishFragment = new ConnectionEstablishFragment();
            connectionEstablishFragment.setActivity(this);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.Main_layout, connectionEstablishFragment);
            fragmentTransaction.commit();
        }
        else if (id == R.layout.fragment_guest) {
            fragmentTransaction = fragmentManager.beginTransaction();
            SubOptionGuestFragment subOptionGuestFragment= new SubOptionGuestFragment();
            subOptionGuestFragment.setActivity(this);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.Main_layout, subOptionGuestFragment);
            fragmentTransaction.commit();}
    }
}










