package com.example.aiet2;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class SubOptionStudentFragment extends Fragment {
    Button btnCaptureStudentAtt;
    Button btnStudentLogin;
    MainActivity mainActivity;
    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view_stdFrag =inflater.inflate(R.layout.fragment_student, container, false);
        btnStudentLogin=  view_stdFrag.findViewById(R.id.btnStudentLogin);
        btnCaptureStudentAtt=view_stdFrag.findViewById(R.id.btnCaptureStudentAtt);
        btnStudentLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              mainActivity.addFragment(R.layout.fragment_login);
            }
        });
        btnCaptureStudentAtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainActivity.addFragment(R.layout.fragment_connection_establish);
            }
        });
        return view_stdFrag;
    }
}