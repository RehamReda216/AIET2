package com.example.aiet2;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class MainFragment extends Fragment {
    Button btnStudent;
    Button btnProfAssis;
    Button btnAdmin;
    Button btnGuest;
    MainActivity mainActivity;
    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view =inflater.inflate(R.layout.fragment_main, container, false);
        btnStudent=view.findViewById(R.id.btnStudent);
        btnProfAssis= view.findViewById(R.id.btnProfAssis);
        btnAdmin=view.findViewById(R.id.btnAdmin);
        btnGuest=view.findViewById(R.id.btnGuest);
        btnStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { mainActivity.addFragment(R.layout.fragment_student);}
        });
        btnProfAssis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { mainActivity.addFragment(R.layout.fragment_prof_assis);}
        });
        btnAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { mainActivity.addFragment(R.layout.fragment_worker);}
        });
        btnGuest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.addFragment(R.layout.fragment_guest);
            }
        });

        return view;
    }

}