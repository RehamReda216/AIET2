package com.example.aiet2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class SubOptionGuestFragment extends Fragment {
        Button btnCaptureGuestAtt;
        Button btnGuestLogin;
        MainActivity mainActivity;

    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view_guest = inflater.inflate(R.layout.fragment_guest, container, false);
        btnCaptureGuestAtt=view_guest.findViewById(R.id.btnCaptureGuestAtt);
        btnGuestLogin=view_guest.findViewById(R.id.btnGuestLogin);
        btnCaptureGuestAtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.addFragment(R.layout.fragment_connection_establish);
            }
        });
        btnGuestLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.addFragment(R.layout.fragment_login);
            }
        });
        return view_guest;
    }
}