package com.example.aiet2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class guest_frag extends Fragment {
        Button btn_cpg;
        Button btn_logg;
        MainActivity mainActivity;

    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view_guest = inflater.inflate(R.layout.fragment_guest_frag, container, false);
        btn_cpg=view_guest.findViewById(R.id.btn_cpg);
        btn_cpg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.addFragment(R.layout.fragment_qr_code);
            }
        });
        btn_logg=view_guest.findViewById(R.id.btn_logg);
        btn_logg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.addFragment(R.layout.fragment_login_frag);
            }
        });
        return view_guest;
    }
}